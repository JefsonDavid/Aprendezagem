<?php

	session_start(); 
  
  	include "conexao.php";
  	include "conectar.php";

    if (isset($_POST['rec'])) {
      echo "<div class='modal-content' style='margin-top: -65px; margin-left: 480px; width: 400px; text-align: center; position: absolute; background-color:'>";
        echo "<div>";
          echo "<img src='img/ok.png' style='width: 200px;'>";
        echo "</div>";
        echo "<div class='modal-header'>";
          echo "<h4 class='modal-title'>Confira o link de confirmação em seu e-mail.</h4>";
          header('refresh:3;url=login.php');
        echo "</div>";
      echo "</div>";
    }
?>

<!DOCTYPE html>
<html>
<head>
	<title>Recupera senha</title>
  <link rel="shortcut icon" href="img/favicon.png" type="image/x-png">
    <!-- CSS compilado e minificado mais recente -->
  <link rel="stylesheet" href="css/css_site/bootstrap.css">

  <!-- Tema opcional -->
  <link rel="stylesheet" href="css/css_site/bootstrap-theme.min.css">

  <!-- O último JavaScript compilado e minificado -->
  <script src="js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container" style="font-size: 16px; width: 400px; height: 400px; margin-top: 120px;" >
		<!-- O ENVIO DOS DADOS DO PARA ESSA MESMA PAGINA PELO METODO POST -->
		<form class="form-signin" action="" method="POST">
        	<h2 class="form-signin-heading">E-mail</h2>
        		<label for="inputEmail" class="sr-only">Email</label>
        		<input type="email" id="inputEmail" style="height: 50px;" class="form-control" name="usuario" placeholder="Digite seu e-mail" required autofocus></br>
        		<button class="btn btn-lg btn-primary btn-block" style="height: 50px;" type="submit" name="rec">Enviar</button>
      	</form>
</body>
</html>