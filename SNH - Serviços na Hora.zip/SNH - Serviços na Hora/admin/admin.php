<?php
	session_start(); 
  
  include "../conexao.php";
  include "../conectar.php";

  $con = new conectar();

  #CONDIÇÃO PARA SAIR DA PAGINA DE ADMIN
	if(isset($_GET['sair']) && $_GET['sair'] == 1){
		unset($_SESSION['usuario']);
		unset($_SESSION['id']);
		header('location: ../index.php');

	}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<!-- CSS compilado e minificado mais recente -->
  	<link rel="stylesheet" href="../css/css_site/bootstrap.css">

  	<!-- Tema opcional -->
  <link rel="stylesheet" href="../css/bootstrap-theme.min.css">

  <!-- O último JavaScript compilado e minificado -->
  <script src="../js/bootstrap.min.js"></script>

</head>
<body>
	<a href="admin.php?sair=1"><button class="btn btn-danger" name="sair" style="font-size: 16px; height: 50px; margin-left: 1200px;">Sair da página</button></a>
	<!-- NOME E QUANTIDADE DE PESSOAS CADASTRADAS NO BANCO DE DADOS -->
	<div class="container card" style="width: 60rem; margin-top: -30px;">
  		<!-- <img class="card-img-top" src="../img/arquivo.png" alt="Card image cap" style="width: 150px;"> -->
  	<div class="card-body">
    	<h3 class="card-title">REGISTROS DO BANCO:</h3>
    	<!-- <p class="card-text">DESCRIÇÃO</p> -->
  	</div>
  		<ul class="list-group list-group-flush">
    		<li class="list-group-item" style="background-color: #08688c; color: white;">
    			<?php
    				echo "<h3>NOME:</h3>";
    				$teste = $con->quantidade();
					foreach ($teste as $dados){
						echo $dados['nome']."</br>";
					}
    			?>
    		</li>
    		<li class="list-group-item">
    			<?php
    				$result = count($teste);
						echo "<h3>QUANTIDADE:</h3>";
						echo "<h3>".$result."</h3>";	
    			?>
    		</li>
  		</ul>
  		<ul class="list-group list-group-flush">
    		<li class="list-group-item" style="background-color: #08688c; color: white;">
    			<?php			
					echo "<h3>SERVIÇOS:</h3>";
					$teste = $con->servicos_cadastrados();
					foreach ($teste as $dados) {
						echo $dados['servico']."</br>";
					}
	    		?>
    		</li>
    		<li class="list-group-item">
    			<?php
    				$result = count($teste);
						echo "<h3>QUANTIDADE:</h3>";
						echo "<h3>".$result."</h3>";	
    			?>
    		</li>
  		</ul>
  		<ul class="list-group list-group-flush">
    		<li class="list-group-item" style="background-color: #08688c; color: white;">
    			<?php			
					echo "<h3>MENSAGEM:</h3>";
					$teste = $con->mensagens();
					foreach ($teste as $dados) {
						echo "<li class='list-group-item' style='background-color: #08688c; color: white;'>".$dados['nome']." - ".$dados['email']." - ".$dados['descricao']."</li>";					}
	    		?>
    		</li>
    		<li class="list-group-item">
    			<?php
    				$result = count($teste);
						echo "<h3>QUANTIDADE:</h3>";
						echo "<h3>".$result."</h3>";	
    			?>
    		</li>
  		</ul>
	</div>
</body>
</html>