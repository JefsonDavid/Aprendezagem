<?php
	session_start();

	include "conexao.php";
	include "conectar.php";

	$con = new conectar();
	
	$id = $_SESSION['id'];//CAPTURA O ID DO CLIENTE LOGADO
	

	//CHAMA O METODO PARA FAZER UMA BUSCA BASEADA NO LOGIN DO CLIENTE
	$cadastro = $con->buscarServico('servico', "WHERE id_cliente = $id");
	$dado = $con->buscarLogin('cliente',"WHERE id = $id");

		//CONDIÇÃO PARA SALVAR OS DADOS AGORA EDITADOS NO BANCO
		if (isset($_POST['salvar'])){
			$id_salvar = $_GET['id_service']; 
			$servico = $_POST['servico_edit'];
			$local = $_POST['local_edit'];
			$fone = $_POST['fone_edit'];
			$email = $_POST['email_edit'];
			$descricao = $_POST['descricao_edit'];

			if($con->atualizar($servico, $local, $fone, $email, $descricao, $id_salvar)){

				echo "<style>
						#body{
							background-color: rgba(0, 0, 0, 0.1);
						}
					</style>";
				
				echo "<div class='modal-content' style='margin-top: 100px; margin-left: 480px; width: 400px; text-align: center; position: absolute;'>";
                  echo "<div>";
                    echo "<img src='img/ok.png' style='width: 200px;'>";
                  echo "</div>";
                  echo "<div class='modal-header'>";
                    echo "<h4 class='modal-title'>Atualizado com sucesso!</h4>";
                  echo "</div>";
                echo "</div>";

				header('refresh:2;url=usuario.php');
			}else{
			 	echo "<h3 style='text-align: center;'>NÃO ATUALIZOU</h3>";
			 	header('refresh:1;url=meus_servicos.php');
			}
		}

		//CONDIÇÃO PARA EXCLUIR UM DADO NO BANCO
		if(isset($_GET['id_service1'])){
			$ex = ($_GET['id_service1']);
			$excluir = $con->deletar($ex);

			if($excluir!=""){

				echo "<style>
						#body{
							background-color: rgba(0, 0, 0, 0.1);
						}
					</style>";
			
				echo "<div class='modal-content' style='margin-top: 100px; margin-left: 480px; width: 400px; text-align: center; position: absolute;'>";
                  	echo "<div>";
                    	echo "<img src='img/ok.png' style='width: 200px;'>";
                  	echo "</div>";
                  	echo "<div class='modal-header'>";
                    	echo "<h4 class='modal-title'>Serviço deletado!</h4>";
                  	echo "</div>";
                echo "</div>";

				header('refresh:2;url=usuario.php');
			}else{
				echo "ERRO!";
				header('refresh:1;url=usuario.php');
			}
		}
	

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>meus serviços</title>
	<link rel="shortcut icon" href="img/favicon.png" type="image/x-png">
	<!-- CSS compilado e minificado mais recente -->
  	<link rel="stylesheet" href="css/css_site/bootstrap.css">

  	<!-- Tema opcional -->
  	<link rel="stylesheet" href="css/css_site/bootstrap-theme.min.css">

  	<!-- O último JavaScript compilado e minificado -->
  	<script src="js/bootstrap.min.js"></script>
</head>
<body id="body">
	<!-- <div style="text-align: right; margin-right: 20px; margin-top: 10px;">
 		<a href="usuario.php"><button type="submit" style="width: 155px;" class="btn btn-danger">VOLTAR</button></a>
 	</div> -->

	<div >
		<form action="" method="POST"> 
			<table class="container table table-" style="width: 600px; margin-left: 400px; background-color: #08688c;color: white; border-radius: 10px;">
				
				<h2 style="text-align: center; color: #29354f; ">SERVIÇOS CADASTRADO: <img src="img/usu.png" style="width: 40px;"> <?php echo $dado['nome']; ?></h2><hr>
				<?php
					//CONDIÇÃO PARA SE VC CLICAR NO BOTÃO EDITAR
					if(isset($_GET['id_service'])){

							$id_service = $_GET['id_service'];
							$editar = $con->buscarUm('servico', "id = $id_service AND id_cliente = $id ");
							//var_dump($editar['servico']);	
							//FORMULÁRIO PARA EDIÇÃO DO BANCO DE DADOS
							echo '<div class="container" style="width: 500px;"><form method="POST">';
							echo '<input type="text" name="servico_edit" value="'.$editar['servico'].'" class="form-control"><br/>';
							echo '<input type="text" name="local_edit" value="'.$editar['local'].'" class="form-control"><br/>';
							echo '<input type="text" name="fone_edit" value="'.$editar['telefone'].'" class="form-control"><br/>';
							echo '<input type="text" name="email_edit" value="'.$editar['email'].'" class="form-control"><br/>';
							echo '<textarea class="form-control" name="descricao_edit">'.$editar['descricao'].'</textarea><br/>
							<input type="submit" class="btn btn-success" style="width: 150px;" name="salvar" value="Salvar">';
							echo '</form></div><br/>';
					}else{
					// if($cadastro!=""){
						echo '<td>';
						foreach ($cadastro as $dados) {
						echo "<h4>"."SERVIÇO:".$dados['servico']." </h4><h4> DESCRIÇÃO: ".$dados['descricao']."</br>";
						//BOTÃO PARA EXCLUIR UM SERVIÇO DO BANCO
						echo '<a href="meus_servicos.php?id_service1='.$dados['id'].'" class="btn btn-danger" style="width: 150px;">Excluir</a>';
						//BOTAO PARA EDITAR UM SERVIÇO DO BANCO 
						echo '<a href="meus_servicos.php?id_service='.$dados['id'].'" class="btn btn-warning" style="width: 150px; margin-left: 10px;">Editar</a></h4>';
					}
						echo '</td>';
					}
				?>	
			</table>
		 </form> 
	</div> 
</body>
</html>