<?php
  session_start(); 
  
  include "conexao.php";
  include "conectar.php";

  $con = new conectar();

  if(isset($_SESSION['id'])){
    $id = $_SESSION['id'];
    $dado = $con->buscarLogin('cliente',"WHERE id = $id");
  }

?>

<!DOCTYPE html>
<html>
<head>
	<title>Contato</title>
  <link rel="shortcut icon" href="img/favicon.png" type="image/x-png">
	<meta charset="utf-8">
	
	<!-- CSS compilado e minificado mais recente -->
	<link rel="stylesheet" href="css/css_site/bootstrap.css">

	<!-- Tema opcional -->
	<link rel="stylesheet" href="css/css_site/bootstrap-theme.min.css">

	<!-- O último JavaScript compilado e minificado -->
	<script src="js/bootstrap.min.js"></script>

  <style>
    #pergunta{
      background-color: #08688c; 
      color: white; 
      border-radius: 5px; 
      height: 80px; 
      text-align: left; 
      width: 700px;
    }

    #per div h3 a button:hover{
      background-color: #ededed;
      color: #08688c;
      margin-left: 20px;
      border-left: solid 15px #ed5923;
      /*border-right: solid 7px #ed5923;*/
      /*border-bottom: solid 7px #ed5923; */
      /*background-color: white;
      color: #08688c;*/
    }
  </style>
</head>
<body>
    <nav class="navbar navbar-dark bg-primary" style="position: fixed; width: 100%; height: 60px; margin-top: -90px; background-color: #08688c;">
        <div class="collapse navbar-collapse" id="navbarText">
        <!-- <ul class="nav nav-tabs" > -->
          <!-- Image and text -->
            <ul class="nav nav-pills">
                <!-- IMAGEM COM LINK PARA O HOME -->
                <li class="nav-item"> 
                  <a class="navbar-brand" href="index.php" style="width: 80px; height: 60px; margin-top: 4px;">
                      <img src="img/snh3.png" width="50" height="50" alt="" style="margin-top: -10px; margin-top: -10px;">
                  </a>
                </li>
                <li class="nav-item" style="width: 150px; text-align: center; margin-top: 15px;">
                  <a class="nav-link" id="link" href="sobre.php" style="height: 50px;"> Sobre nós </a>
                </li>
                <li class="nav-item" style="width: 150px; text-align: center; margin-top: 15px;">
                  <a class="nav-link link" href="contato.php" style="height: 50px;"> Contato </a>
                </li>
                <?php if(empty($dado)){ ?>
                <!-- LINK PARA A PAGINA DE CADASTRO DO CLIENTE -->
                <li class="nav-item" style="width: 150px; text-align: center; margin-top: 15px;">
                  <a class="nav-link link" href="cadastro_cliente.php" style="height: 50px;"> Cadastre-se </a>
                </li>
                <!-- LINK PARA CLIENTE FAZER O LOGIN -->
                <li class="nav-item" style="width: 150px; text-align: center; margin-top: 15px;">
                  <a class="nav-link link" href="login.php" style="height: 50px;"> Login </a>
                </li>
                <?php 
                } else {
                // CODIGO PARA MOSTRAR O NOME DO USUARIO QUE ESTA LOGADO
                echo '<li class="nav-item" style="width: 140px; height: 10px; text-align: center; margin-top: 15px;">
                  <a class="nav-link link" href="usuario.php" style="height: 50px;"><img src="img/usu.png" style="width: 23px;"> '.$dado['nome'].' </a>
                </li>';
                }
                ?>
            </ul>
        </div>
    </nav>
    <!-- FIM DO MENU -->

    <div id="per" style="margin-top: 90px; margin-left: 50px;">
      <div>
        <h3>
          <a href="resp/resposta01.php"><button id="pergunta">Como cadastar um serviço?</button></a><br/>
          <a href="resp/resposta02.php"><button id="pergunta">Como vejo meus serviços?</button></a><br/>
          <a href="contato.php?id=1"><button id="pergunta">Preciso pagar algum valor ou taxa?</button></a>
          <a href="contato.php?id=2"><button id="pergunta">Posso divulgar produto?</button></a>
          <a href="enviar_mensagem.php"><button id="pergunta">Comentários, criticas ou sugestões:</button></a>
        </h3>
      </div>
    </div> 

    <!-- <label style="margin-top: -150px;"><h2>Resposta</h2></label> -->
    <div style="width: 500px; margin-left: 700px; height: 400px; border-radius: 5px; margin-top: -420px;">

      <?php

        if (isset($_GET['id'])) {
          $id = $_GET['id'];

          $resposta = $con->buscarResposta($id);
          foreach ($resposta as $dados) {
            echo "<div style='width: 600px; border-radius: 5px; text-align: justify;'>";
              echo "<h3 style='margin-left: 120px; margin-top: 200px;'>".$dados['resposta']."</h3>";
            echo "</div>";
          }
        }
      ?>
    </div>
</body>
</html>