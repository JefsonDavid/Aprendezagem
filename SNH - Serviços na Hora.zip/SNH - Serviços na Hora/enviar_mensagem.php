<?php
  session_start(); 
  
  include "conexao.php";
  include "conectar.php";

  $con = new conectar();

  if(isset($_SESSION['id'])){
    $id = $_SESSION['id'];
    $dado = $con->buscarLogin('cliente',"WHERE id = $id");
  }

?>

<!DOCTYPE html>
<html>
<head>
	<title>Enviar mensagem</title>
  <link rel="shortcut icon" href="img/favicon.png" type="image/x-png">
	<meta charset="utf-8">
	
	<!-- CSS compilado e minificado mais recente -->
	<link rel="stylesheet" href="css/css_site/bootstrap.css">

	<!-- Tema opcional -->
	<link rel="stylesheet" href="css/css_site/bootstrap-theme.min.css">

	<!-- O último JavaScript compilado e minificado -->
	<script src="js/bootstrap.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-dark bg-primary" style="position: fixed; width: 100%; height: 60px; margin-top: -60px; background-color: #08688c;">
        <div class="collapse navbar-collapse" id="navbarText">
        <!-- <ul class="nav nav-tabs" > -->
          <!-- Image and text -->
            <ul class="nav nav-pills">
                <!-- IMAGEM COM LINK PARA O HOME -->
                <li class="nav-item"> 
                  <a class="navbar-brand" href="index.php" style="width: 80px; height: 50px; margin-top: 4px;">
                      <img src="img/snh3.png" width="50" height="50" alt="" style="margin-top: -13px; margin-top: -10px;">
                  </a>
                </li>
                <li class="nav-item" style="width: 150px; text-align: center; margin-top: 15px;">
                  <a class="nav-link" id="link" href="sobre.php" style="font-size: 13px;"> Sobre nós </a>
                </li>
                <li class="nav-item" style="width: 150px; text-align: center; margin-top: 15px;">
                  <a class="nav-link link" href="contato.php" style="font-size: 13px;"> Contato </a>
                </li>
                <?php if(empty($dado)){ ?>
                <!-- LINK PARA A PAGINA DE CADASTRO DO CLIENTE -->
                <li class="nav-item" style="width: 150px; text-align: center; margin-top: 15px;">
                  <a class="nav-link link" href="cadastro_cliente.php" style="font-size: 13px;"> Cadastre-se </a>
                </li>
                <!-- LINK PARA CLIENTE FAZER O LOGIN -->
                <li class="nav-item" style="width: 150px; text-align: center; margin-top: 15px;">
                  <a class="nav-link link" href="login.php" style="font-size: 13px;"> Login </a>
                </li>
                <?php 
                } else {
                // CODIGO PARA MOSTRAR O NOME DO USUARIO QUE ESTA LOGADO
                echo '<li class="nav-item" style="width: 140px; height: 10px; text-align: center; margin-top: 15px;">
                  <a class="nav-link link" href="usuario.php" style="font-size: 13px;"><img src="img/usu.png" style="width: 23px;"> '.$dado['nome'].' </a>
                </li>';
                }
                ?>
            </ul>
        </div>
    </nav>
    <!-- FIM DO MENU -->

     <div style="text-align: center;">
      <?php
          //CONDIÇÃO PARA CADASTRAR NO BANCO DE DADOS
          if(isset($_POST['enviar'])){

              $nome = $_POST['nome'];
              $email = $_POST['email'];
              $descricao = $_POST['descricao'];



              //ENVIO DOS PARÂMETROS PARA O ARQUIVO CONECTAR.PHP
              $con->setNome($nome);
              $con->setEmail($email);
              $con->setDescricao($descricao);

      
              //CONDIÇÃO PARA SE O CADASTRO FOR EFETUADO COM SUCESSO OU NÃO
              if($con->enviarMsg()){
                // echo "<img src='img/ok.png' style='width: 100px; header: 100px;'";
                echo "<div class='modal-content' style='margin-top: -60px; margin-left: 520px; width: 400px; text-align: center; position: absolute;'>";
                  echo "<div>";
                    echo "<img src='img/ok.png' style='width: 200px;'>";
                  echo "</div>";
                  echo "<div class='modal-header'>";
                    echo "<h4 class='modal-title'>Cadastrado com sucesso!</h4>";
                  echo "</div>";
                echo "</div>";

                header('refresh:7;url=enviar_mensagem.php');
              // } else {
              //   echo ("<h4>MENSAGEM NÃO ENVIADA!</h4>");
              //   echo "<div class='modal-content' style='margin-top: -60px; margin-left: 520px; width: 400px; text-align: center;'>";
              //     echo "<div>";
              //       echo "<img src='img/erro.png' style='width: 200px;'>";
              //     echo "</div>";
              //     echo "<div class='modal-header'>";
              //       echo "<h4 class='modal-title'>Cadastro não efetuado!</h4>";
              //     echo "</div>";
              //   echo "</div>";

              //   header('refresh:2;enviar_mensagem.php');
              }
          }
      ?>
    </div>

    <!-- FORMULÁRIO DE CADASTRO DE USUÁRIOS-->
   <div class="container" style="margin-top: 60px; width: 300px; height: 300px;" >
        <div class="form-group">
            <label><h2>Contato:</h2></label>
             <!-- ENVIO DO FORMULARIO VAI PARA ESSA MESMA PÁG PELO METODO POST -->
            <form action="" method="POST">
                <h4><label>Nome:</label></h4> 
                    <h3><input type="text" class="form-control" name="nome" style="width:350px; height: 50px;" placeholder="EX: João Silva" required></h3>
                <h4><label>E-mail:</label></h4> 
                    <h3><input type="text" class="form-control" name="email" style="width:350px; height: 50px;" placeholder="nome@exemplo.com.br" required></h3>
                <h4><label>Mensagem:</label></h4> 
                    <h3><textarea type="text" class="form-control" name="descricao" maxlength="300" style="width: 350px; height: 70px;" placeholder="Máximo 300 caracteres" required></textarea></h3>    
                    <h3><button type="submit" class="btn btn-primary" name="enviar" style="width: 350px; height: 50px; font-size: 20px;">Enviar Mensagem</button></h3>
            </form>
        </div>
    </div> 