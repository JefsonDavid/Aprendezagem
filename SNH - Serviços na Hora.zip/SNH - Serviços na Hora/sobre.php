<!DOCTYPE html>
<html>
<head>
	<title>Sobre nós</title>
	<link rel="shortcut icon" href="img/favicon.png" type="image/x-png">
	
	<style type="text/css">
		
	body {
		color: black;
		font-size: 20px;
		font-family: sans-serif;
		background-color: white;
		margin-left: 300px;
		margin-right: 300px;
		}
	</style>
	
</head>
<body>
	<div class="container">
		<h1>SNH</h1>
		<p style="text-align: justify;">
			<!-- <img src="img/snh.png" style="width: 100px;"> -->“Serviços na hora e no momento que você mais precisa”
		</p>
	</div>

	<div class="container">
		<h1>Nossa história</h1>
		<p style="width: 100%; text-align: justify;">
			O SNH surgiu de um encontro entre quatro integrantes da nossa equipe. Estávamos pensando sobre novas ideias que poderiam chamar a atenção das pessoas, mas ao mesmo tempo que seria diferente das já lançadas. Então um dos integrantes resolveu reerguer a sua ideia já desenhada antes, porém nunca aplicada e pôr fim a apresentou a todos da equipe. A equipe claramente a apreciou e todos se juntaram para tornar esse projeto em realidade. Entretanto o nosso projeto foi crescendo e as demandas cada vez maiores, o que levou a nossa equipe à procura de um novo integrante, formando agora um time de cinco integrantes. Já com a equipe agora reforçada os nossos objetivos continuaram sendo mais claros, e a cada dia que passasse a motivação de cada integrante fazia com que produzíssemos cada vez mais. Portanto hoje estamos felizes por entregar uma boa parte do projeto, porém, ainda temos muito trabalho a fazer, pois o nosso maior objetivo é fazer com que você (o nosso usuário) confie e utilize os nossos serviços.
		</p>
	</div>

	<div class="container">
		<h1>Missão</h1>
		<p style="width: 100%; text-align: justify;">
			"Nossa missão é ser reconhecido como a melhor e mais confiável fornecedora de serviços brasileira. Procuramos trabalhar para nos manter como uma das melhores fornecedoras, onde o nosso desejo é sempre de melhorar, procurar e aproveitar as novas oportunidades que surgirão para nos tornarmos melhores profissionais. Buscamos continuamente aperfeiçoar nosso negócio de serviços, fornecendo novas funcionalidades sempre que possível"		</p>
	</div>

	<div class="container">
		<h1>Objetivo</h1>
		<p style="width: 100%; text-align: justify;">
			A equipe serviço na hora visa sempre a satisfação dos seus clientes. Procuramos desenvolver um projeto que facilite a vida profissional e pessoal das pessoas, tendo como principal objetivo divulgar profissionais capacitados e facilitar o acesso de pessoas em busca de serviços de qualidade"</p>
	</div>
</body>
</html>

