<!DOCTYPE html>
<html>
<head>
	<title>Resposta</title>
</head>
<body style="text-align: center;">
	<h2>1. Clique em meus serviços</h2>
	<div>
		<img src="../img/meus_ser.png" style="width: 900px;">
	</div>
	<h2>2. Todos os meus serviços cadastrados</h2>
	<div>
		<img src="../img/servico.png" style="width: 900px;">
	</div>
</body>
</html>