<!DOCTYPE html>
<html>
<head>
	<title>Resposta</title>
	<link rel="shortcut icon" href=favicon.png" type="image/x-png">
</head>
<body style="text-align: center;">
	<h2>1. Faça o login</h2>
	<div>
		<img src="../img/menu.png" style="width: 900px;">
	</div>
	<h2>2. Preencha com seus dados</h2>
	<div>
		<img src="../img/login.png" style="width: 900px;">
	</div>
	<h2>3.Você não tem cadastro? clique em cadastra-se</h2>
	<div>
		<img src="../img/cadastre.png" style="width: 900px;">
	</div>
	<h2>4. Depois de efetuar o login, entre na página de usuário</h4>
	<div>
		<img src="../img/pag_usu.png" style="width: 900px;">
	</div>
	<h2>5. Agora você pode cadastrar os seus serviços</h2>
	<div>
		<img src="../img/cad_ser.png" style="width: 900px;">
	</div>
</body>
</html>