<?php
	class conectar extends conexao{
		
		//PAG CADASTRO_CLINTE.PHP
		private $nome;
		private $cidade;
		private $opcao;
		private $email;
		private $senha;
		#================================#
		//PAG USUARIO.PHP
		private $servico;
		private $local;
		private $fone;
		private $emails;
		private $descricao;
		#================================#
		//BANCO DE DADOS
		private $db;

		#================================#
		# === METODO CONSTRUTOR === #
		public function __construct(){
			return $this->db = parent::getDB();
		}
		# ===== METODOS SET ===== #
		//SET PAG CADASTRO_CLIENTE.PHP
		public function setNome($n){
			$this->nome = $n;
		}

		public function setCidade($c){
			$this->cidade = $c;
		}

		public function setOpcao($o){
			$this->opcao = $o;
		}

		public function setEmail($e){
			$this->email = $e;
		}

		public function setSenha($s){
			$this->senha = $s;
		}
		#================================#
		//SET PAG USUARIO.PHP
		public function setServico($se){
			$this->servico = $se;
		}

		public function setLocal($lo){
			$this->local = $lo;
		}

		public function setFone($fo){
			$this->fone = $fo;
		}

		public function setEmails($em){
			$this->emails = $em;
		}

		public function setDescricao($de){
			$this->descricao = $de;
		}
		#================================#
		# ===== METODOS GET ===== #
		//GET PAG CADASTRO_CLIENTE.PHP
		public function getNome(){
			return $this->nome;
		}

		public function getCidade(){
			return $this->cidade;
		}

		public function getOpcao(){
			return $this->opcao;
		}

		public function getEmail(){
			return $this->email;
		}

		public function getSenha(){
			return $this->senha;
		}
		#================================#
		//GET PAG USUARIO.PHP
		public function getServico(){
			return $this->servico;
		}

		public function getLocal(){
			return $this->local;
		}

		public function getFone(){
			return $this->fone;
		}

		public function getEmails(){
			return $this->emails;
		}

		public function getDescricao(){
			return $this->descricao;
		}
		#================================#
		# ===== Metodo para inserir usuarios no banco de dados ======================================#
		public function inserir(){
			$sql = "INSERT INTO cliente (nome, cidade, email, senha) VALUES (:nome, :cidade, :email, :senha)";
			$sql = $this->db->prepare($sql);
			$sql->bindValue(":nome", $this->getNome());
			$sql->bindValue(":cidade", $this->getCidade());
			$sql->bindValue(":email", $this->getEmail());
			$sql->bindValue(":senha", $this->getSenha());

			if($sql->execute()){
				return TRUE;
			}else{
				return FALSE;
			}
		}
		# ======= Metodo para cadastrar Serviços =========================================================#
		public function cadastrar($id_cliente){
			$sql = "INSERT INTO servico (servico, local, estado, telefone, email, descricao, id_cliente) VALUES (:servico, :local, :opcao, :fone, :emails, :descricao, :id)";
			$sql = $this->db->prepare($sql);
			$sql->bindValue(":servico", $this->getServico());
			$sql->bindValue(":local", $this->getLocal());
			$sql->bindValue(":opcao", $this->getOpcao());
			$sql->bindValue(":fone", $this->getFone());
			$sql->bindValue(":emails", $this->getEmails());
			$sql->bindValue(":descricao", $this->getDescricao());
			$sql->bindValue(":id", $id_cliente);

			if($sql->execute()){
				return TRUE;
			}else{
				return FALSE;
			}
		}

		# ======= Metodo para login =======================================================================#
		public function loginUser($or){
			$sql = "SELECT * FROM cliente WHERE $or";
			$sql = $this->db->prepare($sql);
			$sql->execute();
			$dados = $sql->fetch();

			if($sql->rowCount() == 1){
				//var_dump($dados); exit();
				$_SESSION['id'] = $dados['id'];
				$_SESSION['nome'] = $dados['nome'];
				return TRUE;
			}else{
				return FALSE;
			}
		}

		# ======= Metodo para login do admin ==============================================================#
		public function loginAdmin($or){
			$sql = "SELECT * FROM administrador WHERE $or";
			$sql = $this->db->prepare($sql);
			$sql->execute();
			$dados = $sql->fetch();

			if($sql->rowCount() == 1){
				//var_dump($dados); exit();
				// $_SESSION['id'] = $dados['id'];
				// $_SESSION['nome'] = $dados['nome'];
				return TRUE;
			}else{
				return FALSE;
			}
		}

		#======= Metodo para listar todos os valores cadastrados no banco de dados ========================#
		public function listar(){
			$sql = "SELECT * FROM servico ORDER BY id DESC LIMIT 5";
			$sql = $this->db->prepare($sql);
			$sql->execute();
			return $sql->fetchAll(PDO::FETCH_ASSOC);
		}

		#====== Metodo de busca pelo email do cliente =====================================================#
		public function buscarServico($table, $where = NULL){
			$sql = "SELECT * FROM $table $where";
			$sql = $this->db->prepare($sql);
			$sql->execute();
			return $sql->fetchAll(PDO::FETCH_ASSOC);
			//var_dump($dados);
		}

		#====== Metodo de busca pelo email do cliente =====================================================#
		public function buscarLogin($table, $where = NULL){
			$sql = "SELECT nome FROM $table $where";
			$sql = $this->db->prepare($sql);
			$sql->execute();
			return $sql->fetch();
			//var_dump($dados);
		}

		# ======= Metodo para fazer uma busca =============================================================#
		public function buscarNome($table, $nome){
			$sql = "SELECT * FROM $table WHERE $nome";
			$sql = $this->db->prepare($sql);
			$sql->execute();
			return $sql->fetchAll(PDO::FETCH_ASSOC);
		}

		# ======= Metodo para fazer uma busca =============================================================#
		public function buscarUm($table, $nome){
			$sql = "SELECT * FROM $table WHERE $nome";
			$sql = $this->db->prepare($sql);
			$sql->execute();
			return $sql->fetch();
		}

		# ===== Metodo para buscar uma resposta sobre as perguntas mais frequentes ======================== #
		public function buscarResposta($id){
			$sql = "SELECT * FROM resposta WHERE ID=$id";
			$sql = $this->db->prepare($sql);
			$sql->execute();

			return $sql->fetchAll(PDO::FETCH_ASSOC);
		}

		# ======= Metodo para atualizar o meu banco de dados ==============================================#
		public function atualizar($servico, $local, $fone, $email, $descricao, $id){
			$sql = "UPDATE servico SET  servico = ?, local = ?, telefone = ?, email = ?, descricao = ? WHERE id = ?";
			$sql = $this->db->prepare($sql);
			$sqlarray = array("$servico", "$local", "$fone", "$email", "$descricao", "$id");
				if($sql->execute($sqlarray)){
					return true;
				}else{
					return false;
				}
		}
		# ======= Metodo para excluir no banco de dados =====================================================#
		public function deletar($id){
			$sql = "DELETE FROM servico WHERE ID=$id";
			$sql = $this->db->prepare($sql);
			if($sql->execute()){
				return true;
			}else{
				return false;
			}
		}
		# ======= Metodo para cadastrar mensagem =========================================================# 
		public function enviarMsg(){
			$sql = "INSERT INTO mensagem (nome, email, descricao) VALUES (:nome, :email, :descricao)";
			$sql = $this->db->prepare($sql);
			$sql->bindValue(":nome", $this->getNome());
			$sql->bindValue(":email", $this->getEmail());
			$sql->bindValue(":descricao", $this->getDescricao());

			if($sql->execute()){
				return TRUE;
			}else{
				return FALSE;
			}
		}

		#=================== Metodo para fazer uma busca por serviço ou por local ===========================#
		public function buscar($buscar, $estado){
			$sql = "SELECT * FROM servico WHERE (servico = '$buscar' OR local ='$buscar') AND estado = '$estado'";
			$sql = $this->db->prepare($sql);
			$sql->execute();
			return $sql->fetchAll(PDO::FETCH_ASSOC);
		}

		public function buscarTudo($buscar){
			$sql = "SELECT * FROM servico WHERE servico = '$buscar' OR local ='$buscar'";
			$sql = $this->db->prepare($sql);
			$sql->execute();
			return $sql->fetchAll(PDO::FETCH_ASSOC);
		}


		#====================================================================================================#
		#======================================= OPÇÕES DO ADMINISTRADOR ====================================#
		#====================================================================================================#
		//MOSTRA TODOS OS NOMES DOS CLIENTES CADASTRADOS E A QUANTIDADE
		public function quantidade(){
			$sql = "SELECT DISTINCT nome FROM cliente";//o DISTINCT não deixa trazer valores repetidos
			$sql = $this->db->prepare($sql);
			$sql->execute();
			return $sql->fetchAll(PDO::FETCH_ASSOC);
		}

		//MOSTRA TODOS OS SERVIÇOS CADASTRADOS E A QUANTIDADE 
		public function servicos_cadastrados(){
			$sql = "SELECT DISTINCT servico FROM servico";//o DISTINCT não deixa trazer valores repetidos
			$sql = $this->db->prepare($sql);
			$sql->execute();
			return $sql->fetchAll(PDO::FETCH_ASSOC);
		}

		//MOSTRA TODAS AS MENSAGENS CADASTRADAS E A QUANTIDADE
		public function mensagens(){
			$sql = "SELECT DISTINCT nome, email, descricao FROM mensagem";//o DISTINCT não deixa trazer valores repetidos
			$sql = $this->db->prepare($sql);
			$sql->execute();
			return $sql->fetchAll(PDO::FETCH_ASSOC);
		}

		public function localizar($estado){
			$sql = "SELECT * FROM servico WHERE estado = '$estado'";
			$sql = $this->db->prepare($sql);
			$sql->execute();
			return $sql->fetchAll(PDO::FETCH_ASSOC);
		}


	}
?>
