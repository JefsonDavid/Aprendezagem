<?php
  session_start(); 
  
  include "conexao.php";
  include "conectar.php";

  $con = new conectar();
    
  if(isset($_SESSION['id'])){
    $id = $_SESSION['id'];
    $dado = $con->buscarLogin('cliente',"WHERE id = $id");
  }

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Página principal</title>
  <link rel="shortcut icon" href="img/favicon.png" type="image/x-png">
  <meta charset="utf-8">
  <!-- CSS compilado e minificado mais recente -->
  <link rel="stylesheet" href="css/css_site/bootstrap.css">
  <!-- <link href="css/carousel.css" rel="stylesheet"> -->

  <link rel="stylesheet" type="text/css" href="css/css_site/style.css">

  <!-- Tema opcional -->
  <link rel="stylesheet" href="css/css_site/bootstrap-theme.min.css">

  <!-- O último JavaScript compilado e minificado -->
  <script src="js/bootstrap.min.js"></script>
  <!-- <script src="js/jquery.min.js"></script> -->


    <!-- CSS e JS do MAPA -->
    <!-- <link rel="stylesheet" type="text/css" href="estilo.css">
    <script type="text/javascript" src="funcoes.js"></script>
 -->
  <style>
    #card{ 

      margin-top: 100px;
      margin-left: 10%;
      width: 20%;

    }

    #titulo{
      color: white;
    }
  </style>

</head>
<body id="body_inicial">
    <!-- ======================================== MENU ============================================= -->
    <nav class="navbar navbar-dark bg-primary" id="nav_menu">
      <div class="collapse navbar-collapse" id="navbarText">
        <!-- <ul class="nav nav-tabs" > -->
        <!-- Image and text -->
        <ul class="nav nav-pills">
          <!-- IMAGEM COM LINK PARA O HOME -->
          <li class="nav-item" id="li_img"> 
            <a class="navbar-brand" href="index.php" id="a_img">
              <img src="img/snh3.png" width="50" height="50" alt="" id="img">
            </a>
          </li>
          <!-- FIM DA IMAGEM -->
          
          <!-- FORMULÁRIO PARA FAZER BUSCA NO BANCO -->
          <!-- <li id="li_buscar">
            <form action="" method="POST" class="form-inline my-2 my-lg-0" id="form_buscar">
              <input class="form-control mr-sm-2" type="text" name="bus" placeholder="Procure por serviços de sua preferência" aria-label="Buscar" id="input_buscar">
              
              <a href="#titulo"><button class="btn btn-outline-success my-2 my-sm-0" type="submit" name="buscar" id="button_buscar">Buscar</button></a>

            </form> -->
          </li>
          <!-- FIM DO FORMULÁRIO -->
          <!-- LINK PARA A PÁGINA QUE FALA SOBRE O SITE -->
          <li class="nav-item" id="li_sobre">
            <a class="nav-link" id="link" href="sobre.php" id="a_sobre"> Sobre nós </a>
          </li>
          <!-- LINK PARA A PÁGINA DO FORMULÁRIO DE CONTATO COM A EQUIPE DO SITE -->
          <li class="nav-item" id="li_contato">
             <a class="nav-link link" href="contato.php" id="a_contato"> Contato </a>
          </li>
          <!-- CODIGO EM PHP PARA SE O CLIENTE ESTIVER LOGADO NA APARECER OS LINK DE cadastrar E login -->
          <?php if(empty($dado)){ ?>
            <!-- LINK PARA A PAGINA DE CADASTRO DO CLIENTE -->
            <li class="nav-item" id="li_cadastre">
               <a class="nav-link link" href="cadastro_cliente.php" id="a_cadastre"> Cadastre-se </a>
            </li>
            <!-- LINK PARA CLIENTE FAZER O LOGIN -->
            <li class="nav-item" id="li_login">
               <a class="nav-link link" href="login.php" id="a_login"> Login </a>
            </li>
          <?php 
            } else {
              // CODIGO PARA MOSTRAR O NOME DO USUARIO QUE ESTA LOGADO
              echo '<li class="nav-item" id="li_usuario">
              <a class="nav-link link" href="usuario.php" id="a_usuario"><img src="img/usu.png" id="img_usuario"> '.$dado['nome'].'</a>
              </li>';
            }
            ?>
        </ul>
      </div>
    </nav>
    <!-- ================================== FIM DO MENU =========================================== -->

     <!-- ========================== PAINEL DA TELA INICIAL ======================================= -->
      <div class="carousel-item" id="div_painel">
        <img src="img/painel4.jpg" id="img_painel" alt="...">
        <li id="li_buscar">
            <form action="" method="POST" class="form-inline my-2 my-lg-0" id="form_buscar" style="margin-top: -260px; margin-left: 250px; margin-right: -250px;">
              <input class="form-control mr-sm-2" type="text" name="bus" placeholder="Procure por serviços de sua preferência" aria-label="Buscar" id="input_buscar" style="height: 60px; font-size: 20px;">
              
              <a href="#titulo"><button class="btn btn-outline-success my-2 my-sm-0" type="submit" name="buscar" id="button_buscar" style="height: 60px; width: 130px; font-size: 20px; background-color: #f97527;">Buscar</button></a>

            </form>
          </li>
        <h3 id="h3_painel" style="color: #064d68;"> SNH </h3>
          <p id="p_painel" style="color: #064d68;">Serviços na Hora</p>
      </div>
    <!-- ============================= FIM PAINEL DA TELA INICIAL ================================= -->

    <!-- ======= A PARTE ABAIXO MOSTRA TODOS OS VALORES PESQUISADOS NO BANCO USANDO O $_GET['ESTADO'] ======= -->
    <div id="card">
      <form>
        <dir> 
          <?php
            $servico = "";

            if(isset($_POST['buscar']) && ($_GET['estado'])){ 
            $resultado = $_POST['bus'];
            $estado = $_GET['estado'] ;
    
              $servico = $con->buscar($resultado, $estado);
              echo "<div style='z-index:-99;'>";
              foreach ($servico as $dados) {

                echo "<div class='card' id='busca_servico' style='width: 60rem;'>";
                  echo "<div class='card-body'>";
                    echo "<li id='li' class='list-group-item' style='background-color: #08688c; z-index:-99;'>";
                      echo "<h3 class='card-title'>";

                        echo "<h3 id='titulo'>".$dados['servico']."</h3>";
                         
                      echo "</h3>";
                    echo "</li>";
                    echo "<li class='list-group-item' style='z-index:-99;'>";
                      echo "<p class='card-text'>";
            
                        echo $dados['descricao'];
                        
                      echo "</p>";
                    echo "</li>";
                  echo "</div>";
                    echo "<ul class='list-group list-group-flush'>";
                      echo "<li class='list-group-item' style='z-index:-99;'>";
                        
                        echo $dados['telefone'];
                        
                      echo "</li>";
                      echo "<li class='list-group-item' style='z-index:-99;'>";
                        
                        echo $dados['email'];
                        
                      echo "</li>";
                      echo "<li class='list-group-item' style='z-index:-99;'>";
                        
                        echo $dados['local'];
                        
                      echo "</li>";
                    echo "</ul>";
                  echo "</div>";
              }  
                echo "</div>";  
            // }else{ 
          #====================== FIM DOS VALORES BUSCADOS NO BANCO ===================================#
          

          #=========================== VALORES DA PESQUISA PELO MAPA ==================================#
            }elseif(isset($_GET['estado'])){
            $estado = $_GET['estado'];

              $local = $con->localizar($estado);
              echo "<div style='z-index:-99;'>";
              foreach ($local  as $dados) {
                echo "<div class='card' style='width: 60rem;'>";
                  echo "<div class='card-body'>";
                    echo "<li class='list-group-item' style='background-color: #08688c; z-index:-99;'>";
                      echo "<h3 class='card-title'>";

                        echo "<h3 id='titulo'>".$dados['servico']."</h3>";
                           
                      echo "</h3>";
                    echo "</li>";
                    echo "<li class='list-group-item' style='z-index:-99;'>";
                      echo "<p class='card-text'>";
              
                        echo $dados['descricao'];
                          
                      echo "</p>";
                    echo "</li>";
                  echo "</div>";
                    echo "<ul class='list-group list-group-flush'>";
                      echo "<li class='list-group-item' style='z-index:-99;'>";
                          
                        echo $dados['telefone'];
                          
                      echo "</li>";
                      echo "<li class='list-group-item' style='z-index:-99;'>";
                          
                        echo $dados['email'];
                          
                      echo "</li>";
                      echo "<li class='list-group-item' style='z-index:-99;'>";
                          
                        echo $dados['local'];
                          
                      echo "</li>";
                    echo "</ul>";
                  echo "</div>";
              }  
                echo "</div>";
              }
              ?>
          </dir>
        </form>
      </div>
   <!-- ============================ FIM DA PESQUISA PELO MAPA =================================== -->

    <!-- =================================== PAGINAÇÃO ============================================= -->
    <!-- <nav aria-label="Page navigation example" style="text-align: center; margin-left: 200px;">
      <ul class="pagination">
        <li class="page-item">
          <a class="page-link" href="#" aria-label="Previous">
            <span aria-hidden="true">&laquo;</span>
            <span class="sr-only">Previous</span>
          </a>
        </li>
        <li class="page-item"><a class="page-link" href="#">1</a></li>
        <li class="page-item"><a class="page-link" href="#">2</a></li>
        <li class="page-item"><a class="page-link" href="#">3</a></li>
        <li class="page-item">
          <a class="page-link" href="#" aria-label="Next">
            <span aria-hidden="true">&raquo;</span>
            <span class="sr-only">Next</span>
          </a>
        </li>
      </ul>
    </nav> -->

    <!-- ================================ FIM DA PAGINAÇÃO ====================================== -->
    <hr> 
    <footer id="footer">
      <!-- <img src="img/rodape.jpg" style="width: 100%;"> -->
        <a href="https://www.facebook.com/"> <img src="img/face.png" id="a_footer"></a> 
         <a href="https://www.instagram.com/"><img src="img/insta.png" id="a_footer"></a>
         <a href="https://www.twitter.com/"><img src="img/twiter.png" id="a_footer"></a>
        <p id="p_footer"> © Copyright 2017 - by Serviços na Hora LTDA <br/></p>
    </footer>
</body>
</html>