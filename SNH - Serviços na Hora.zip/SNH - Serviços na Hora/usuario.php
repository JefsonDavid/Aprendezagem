<?php

	session_start();

	include "conexao.php";
	include "conectar.php";

	$con = new conectar();
	$id = $_SESSION['id'];

	#CONDIÇÃO PARA NÃO ENTRAR SEM SENHA E LOGIN
	if(empty($_SESSION['usuario'])){
		echo "<h1>Vc precisa estar logado!</h1>";
		header('refresh:2;url=login.php');
		exit();
	}

	#CONDIÇÃO PARA SAIR DA PAGINA
	if(isset($_GET['sair']) && $_GET['sair'] == 1){
		unset($_SESSION['usuario']);
		unset($_SESSION['id']);
		header('location: index.php');

	}


?>
<!DOCTYPE html>
<html>
<head>
	<title>Página do usuário</title>
	<link rel="shortcut icon" href="img/favicon.png" type="image/x-png">
	<!-- CSS compilado e minificado mais recente -->
  	<link rel="stylesheet" href="css/css_site/bootstrap.css">

  	<!-- Tema opcional -->
  	<link rel="stylesheet" href="css/css_site/bootstrap-theme.min.css">

  	<!-- O último JavaScript compilado e minificado -->
  	<script src="js/bootstrap.min.js"></script>
</head>
<body id="body">
	<!-- MENU -->
    <nav class="navbar navbar-dark bg-primary" style="background-color: #08688c; height: 60px;"> 
    	<div class="collapse navbar-collapse" id="navbarText">
      		<form action="" method="POST">
      		<!-- Image and text -->
	      	<ul class="nav nav-pills">
	        	<li class="nav-item"> 
	          		<a class="navbar-brand" href="index.php" style="width: 80px; height: 60px; margin-top: 4px;">
	              		<img src="img/snh3.png" width="50" height="50" style="margin-top: -10px;">
	            	</a>
	        	</li>
	          	<li style="width: 150px; text-align: center; margin-top: 5px;">
	            	<a class="btn" href="meus_servicos.php"  style="height: 60px; font-size: 18px;">Meus serviços</a>
	          	</li>
	          	<!-- <li>
	            	<a class="btn" href="cadastrar_servicos.php" style="font-size: 16px; height: 50px;">CADASTRAR NOVO SERVIÇO</a>
	          	</li> -->
				<li class="nav-item" style="margin-left: 950px; /*background-color: #ff863f;*/ color: #ffffff; font-size: 18px; border-radius: 5px; margin-top: 3px;">
	            	<a class="btn" href="usuario.php?sair=1" name="sair" style="font-size: 18px; height: 60px;"> Sair da página</a>
	          	</li> 
	        </ul>
	        </form>
	    </div>
	</nav>
	<div style="text-align: center;" >
    	<?php
		    //CONDIÇÃO PARA CADASTRAR NO BANCO DE DADOS
			if(isset($_POST['cadastrar'])){

				$servico = $_POST['servico'];
				$local = $_POST['local'];
				$estado = $_POST['opcao'];
				$email = $_POST['email'];
				$fone = $_POST['fone'];
				$descricao = $_POST['descricao'];

				//ENVIO DOS PARÂMETROS PARA O ARQUIVO CONECTAR.PHP
				$con->setServico($servico);
				$con->setLocal($local);
				$con->setOpcao($estado);
				$con->setEmails($email);
				$con->setFone($fone);
				$con->setDescricao($descricao);


			    //CONDIÇÃO PARA SE O CADASTRO FOR EFETUADO COM SUCESSO OU NÃO
				if($con->cadastrar($id)){
					
					echo "<style>
						#body{
							background-color: rgba(0, 0, 0, 0.1);
						}
					</style>";

					echo "<div class='modal-content' style='margin-top: 55px; margin-left: 480px; width: 400px; text-align: center; position: absolute; background-color:'>";
	                  	echo "<div>";
	                    	echo "<img src='img/ok.png' style='width: 200px;'>";
	                  	echo "</div>";
	                  	echo "<div class='modal-header'>";
	                    	echo "<h4 class='modal-title'>Cadastrado com sucesso!</h4>";
	                  	echo "</div>";
	                echo "</div>";
					
					header('refresh:2;url=usuario.php');
				} else {
					
					 echo "<div class='modal-content' style='margin-top: -60px; margin-left: 480px; width: 400px; text-align: center; position: absolute;'>";
		                echo "<div>";
		                    echo "<img src='img/erro.png' style='width: 200px;'>";
		                echo "</div>";
		                echo "<div class='modal-header'>";
		                    echo "<h4 class='modal-title'>Cadastrado com sucesso!</h4>";
		                echo "</div>";
		            echo "</div>";

					header('refresh:2;url=usuario.php');
				}
			}
		?>
    </div>
 	<!-- <div style="text-align: right; margin-right: 20px; margin-top: 10px;">
 		<a href="usuario.php"><button type="submit" style="width: 155px;" class="btn btn-danger">VOLTAR</button></a>
 	</div> -->
 	<!-- FORMULÁRIO DE CADASTRO DE SERVIÇOS-->
	<div class="container" style="width: 400px;" > <!-- margin-left: 50px; -->
		<div class="form-group">
			<!-- ENVIO DO FORMULARIO VAI PARA ESSA MESMA PÁG PELO METODO POST -->
			<form action="" method="POST" style="margin-top: -30px;">
				<label><h2>Cadastro de Serviço</h2></label>
				<h4><label>Serviço:</label></h4> 
					<h3><input type="text" class="form-control" name="servico" placeholder="EX: Médico" required></h3>
				<h4><label>Local:</label></h4> 
					<h3><input type="text" class="form-control" name="local" style="width: 295px;" placeholder="EX: Luziânia" required>

					<select class="form-control" name="opcao" style="width:70px; margin-left: 300px; margin-top: -34px;">
				   		<option value="DF">DF</option>
				    	<option value="RS">RS</option>
				    	<option value="SC">SC</option>
				    	<option value="PR">PR</option>
				    	<option value="SP">SP</option>
				    	<option value="RJ">RJ</option>
				    	<option value="MG">MG</option>
				    	<option value="ES">ES</option>
				    	<option value="GO">GO</option>
				    	<option value="TO">TO</option>
				    	<option value="MT">MT</option>
				    	<option value="MS">MS</option>
				    	<option value="BA">BA</option>
				    	<option value="SE">SE</option>
				    	<option value="AL">AL</option>
				    	<option value="PE">PE</option>
				    	<option value="PB">PB</option>
				    	<option value="RN">RN</option>
				    	<option value="CE">CE</option>
				    	<option value="PI">PI</option>
				    	<option value="MA">MA</option>
				    	<option value="PA">PA</option>
				    	<option value="AP">AP</option>
				    	<option value="RR">RR</option>
				    	<option value="AM">AM</option>
				    	<option value="RO">RO</option>
				    	<option value="AC">AC</option>  	
				</select>	


					</h3>
				<h4><label>telefone:</label></h4> 
					<h3><input type="text" class="form-control" name="fone" max="12" placeholder="(99) 99999-9999" required></h3>
				<h4><label>E-mail:</label></h4> 
					<h3><input type="text" class="form-control" name="email" placeholder="nome@exemplo.com.br" required></h3>
				<h4><label>Descrição:</label></h4> 
					<h3><textarea type="text" class="form-control" name="descricao" maxlength="150"  placeholder="Máximo 150 caracteres" required></textarea></h3>	
				<h3><button type="submit" style="width: 370px; height: 40px; font-size: 20px;" class="btn btn-primary" name="cadastrar">Cadastrar</button></h3>

			</form>
		</div>
	</div>	    
</body>
</html>