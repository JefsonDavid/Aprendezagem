<?php
	session_start();

	if(!empty($_SESSION['usuario'])){
		header('refresh:1;url=usuario.php');
	}

	//INCLUINDO CONEXÕES COM O BANCO DE DADOS E AS CLASSES
	include "conexao.php";
	include "conectar.php";

	$con = new conectar();

	//CONDIÇÃO PARA FAZER O LOGIN
	if(isset($_POST['login'])){
		$user = $_POST['usuario'];
		$pass = base64_encode($_POST['senha']); //DESCRIPTOGRAFANDO SENHA 

		//PRIMEIRO VAI VERIFICAR SE QUEM ESTÁ SE LOGANDO EH UM ADMIN
		$var = $con->loginAdmin("email = '$user' AND senha = '$pass'");
		if($var){
			$_SESSION['usuario'] = true;
			header('location:admin/admin.php');
		}else{
			// echo "<h2>Erro! Tente novamente</h2>";
			header('refresh:2;url=login.php');
		} 

		//CHAMADA DO METODO LoginUser E ENVIO DE VALOR PAPRA EFETUAR O LOGIN
		$var = $con->loginUser("email = '$user' AND senha = '$pass'");

		//CONDIÇÃO PARA SE O LOGIN FOR EFETUADO COM SUCESSO OU NÃO
		if($var){
			$_SESSION['usuario'] = true;
			header('location:index.php');

		}else{
			// echo "<h2>Erro! Tente novamente</h2>";
			header('refresh:2;url=login.php');
		}
	}

?>

<!DOCTYPE html>
<html>
<head>
	<title>login</title>
	<link rel="shortcut icon" href="img/favicon.png" type="image/x-png">
  <!-- CSS compilado e minificado mais recente -->
  <link rel="stylesheet" href="css/css_site/bootstrap.css">

  <!-- Tema opcional -->
  <link rel="stylesheet" href="css/css_site/bootstrap-theme.min.css">

  <!-- O último JavaScript compilado e minificado -->
  <script src="js/bootstrap.min.js"></script>
</head>
<!--  TESTAR ESTA FONTE #58ceaf -->
<body background="img/painel50.jpg" style="width: 100%;">

	<!-- IMAGEM DO LOGO NA PARTE SUPERIOR DA PAGINA DE LOGIN -->
	<!-- <div>
		<img src="img/p11.jpg" style="width: 250px; height: 150px; margin-left: 550px;" >
	</div> -->
	<!-- FORMULÁRIO DE LOGIN E SENHA -->

	<div class="modal-content container" style="font-size: 16px; width: 400px; background-color: white; height: 660px; border-radius: 5px;">
		<!-- O ENVIO DOS DADOS DO PARA ESSA MESMA PAGINA PELO METODO POST -->
		<form class="form-signin" action="" method="POST" style="margin-top: 30px;">
			<img src="img/snh3.png" style="width: 250px; margin-left: 50px;">
        	<h2 class="form-signin-heading">Login</h2>
        		<label for="inputEmail" class="sr-only">Email address</label>
        		<input type="email" id="inputEmail" class="form-control" name="usuario" placeholder="Email address" required autofocus style="height: 50px; font-size: 16px;"></br>
        		<label for="inputPassword" class="sr-only">Password</label>
        		<input type="password" id="inputPassword" class="form-control" name="senha" placeholder="Password" required style="height: 50px; font-size: 16px;">
        		<div class="checkbox">
          			<label>
            			<input type="checkbox" value="remember-me"> Remember me
          			</label>
        		</div>
        		<button class="btn btn-lg btn-primary btn-block" type="submit" name="login" style="height: 50px; font-size: 20px;">Sign in</button>
      	</form>
      		</br>
      		<a href="cadastro_cliente.php">Cadastre-se</a>
      		<a href="nova_senha.php" style="margin-left: 130px;">Esqueceu a senha?</a>
    </div> 
</body>
</html>