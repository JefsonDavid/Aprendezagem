<?php
	abstract class conexao{

		private static function conectar(){
			try{
				return $con = new PDO("mysql:host=localhost; dbname=teste; root","root");
			}catch(PDOExepition $e){
				echo "Erro ao se conectar".$e->getMessage();
			}
		}

		protected static function getDB(){
			return self::conectar();
		}
	}
?>