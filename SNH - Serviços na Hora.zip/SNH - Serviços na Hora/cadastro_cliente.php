<?php
	session_start();

	//INCLUINDO A CONEXÃO COM O BANCO DE DADOS E TBM AS CLASSES
	include "conexao.php";
	include "conectar.php";

	$con = new conectar();


?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Cadastro de cliente</title>
	<link rel="shortcut icon" href="img/favicon.png" type="image/x-png">
	<meta charset="utf-8">
	<!-- CSS compilado e minificado mais recente -->
	<link rel="stylesheet" href="css/css_site/bootstrap.css">

	<!-- Tema opcional -->
	<link rel="stylesheet" href="css/css_site/bootstrap-theme.min.css">

	<!-- O último JavaScript compilado e minificado -->
	<script src="js/bootstrap.min.js"></script>

</head>
<body>
	<!-- =================== MENU =================== -->
    <nav class="navbar navbar-dark bg-primary" style="position: fixed; width: 1366px;height: 60px; margin-top: -60px; background-color: #08688c">
      	<div class="collapse navbar-collapse" id="navbarText">
        <!-- <ul class="nav nav-tabs" > -->
        	<!-- Image and text -->
        	<ul class="nav nav-pills">
          		<!-- IMAGEM COM LINK PARA O HOME -->
          		<li class="nav-item"> 
            		<a class="navbar-brand" href="index.php" style="width: 80px; height: 60px; margin-top: 4px;">
              			<img src="img/snh3.png" width="50" height="50" alt="" style="margin-top: -10px;">
            		</a>
          		</li>
          		<li class="nav-item" style="width: 100px; text-align: center; margin-top: 15px; text-align: center;">
            		<a class="nav-link" id="link" href="sobre.php" style="height: 50px;"> Sobre nós </a>
          		</li>
          		<li class="nav-item" style="width: 100px; text-align: center; margin-top: 15px; text-align: center;">
             		<a class="nav-link link" href="contato.php" style="height: 50px;"> Contato </a>
          		</li>
          		<li class="nav-item" style="width: 110px; text-align: center; margin-top: 15px; text-align: center;">
             		<a class="nav-link link" href="cadastro_cliente.php" style="height: 50px;"> Cadastre-se </a>
          		</li>
          		<?php if(empty($dado)){ ?>
            	<li class="nav-item" style="width: 100px; text-align: center; margin-top: 15px; text-align: center;">
               		<a class="nav-link link" href="login.php" style="height: 50px;"> Login </a>
            	</li>
          		<?php 
            	} else {
              	echo '<li class="nav-item" style="width: 150px; text-align: center;">
              		<a class="nav-link link" href="usuario.php" style="height: 50px;">'.$dado['nome'].' </a>
              	</li>';
            	}
            	?>
        	</ul>
      	</div>
    </nav>
 	<!-- FIM DO MENU -->
 	<div style="text-align: center; margin-top: 60px;">
 		<?php
 			//CONDIÇÃO PARA CADASTRAR NO BANCO DE DADOS
			if(isset($_POST['cadastrar'])){
		
				$nome = $_POST['nome'];
				$cidade = $_POST['cidade'];
				$email = $_POST['email'];
				$senha = $_POST['senha'];

				//ENVIO DOS PARÂMETROS PARA O ARQUIVO CONECTAR.PHP
				$con->setNome($nome);
				$con->setCidade($cidade);
				$con->setEmail($email);
				$con->setSenha(base64_encode($senha)); //CRIPTOGRAFANDO SENHA

				//CONDIÇÃO PARA SE O CADASTRO FOR EFETUADO COM SUCESSO OU NÃO
				if($con->inserir()){
					echo "<div class='modal-content' style='margin-top: -60px; margin-left: 480px; width: 400px; text-align: center; position: absolute; background-color:'>";
	                  	echo "<div>";
	                    	echo "<img src='img/ok.png' style='width: 200px;'>";
	                  	echo "</div>";
	                  	echo "<div class='modal-header'>";
	                    	echo "<h4 class='modal-title'>Cadastrado com sucesso!</h4>";
	                  	echo "</div>";
	                echo "</div>";
					// echo "DADOS CADASTRADOS COM SUCESSO!";
					header('refresh:2;url=login.php');
				}else{
					echo "<div class='modal-content' style='margin-top: -60px; margin-left: 480px; width: 400px; text-align: center; position: absolute; background-color:'>";
	                  	echo "<div>";
	                    	echo "<img src='img/erro.jpg' style='width: 200px;'>";
	                  	echo "</div>";
	                  	echo "<div class='modal-header'>";
	                    	echo "<h4 class='modal-title'>Cadastro não efetuado!</h4>";
	                  	echo "</div>";
	                echo "</div>";


					header('refresh:2;url=cadastro_cliente.php');
				}
			}
 		?>
 	</div>

	<!-- FORMULÁRIO DE CADASTRO DE USUÁRIOS-->
	<div class="container" style="margin-top: 60px; width: 400px; height: 400px;" >
		<div class="form-group">
			<label><h2>Cadastro de cliente:</h2></label>
		<!-- ENVIO DO FORMULARIO VAI PARA ESSA MESMA PÁG PELO METODO POST -->
		<form action="" method="POST">
			<h4><label>Nome:</label></h4> 
				<h3><input type="text" class="form-control" name="nome" style="width:350px; height: 45px;" placeholder="EX: João Silva" required></h3>
			<h4><label>Cidade:</label></h4> 
				<h3><input type="text" class="form-control" name="cidade" style="width:350px; height: 45px;" placeholder="EX: Brasilia" required></h3>
			<h4><label>E-mail:</label></h4> 
				<h3><input type="text" class="form-control" name="email" style="width:350px; height: 45px;" placeholder="nome@exemplo.com.br" required></h3>
			<h4><label>Senha:</label></h4> 
				<h3><input type="password" class="form-control" name="senha" style="width:350px; height: 45px;" placeholder="Use de 6 a 20 caractere" required></h3>
			<h3><button type="submit" class="btn btn-primary" name="cadastrar" style="width: 350px; height: 45px; font-size: 20px;">Cadastrar</button></h3>
		</form>
		</div>
	</div>
</body>
</html>